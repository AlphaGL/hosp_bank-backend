from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework_simplejwt.views import TokenRefreshView
from patients.auth_views import LoginView, LogoutView, StaffProfileView

urlpatterns = [
    path('admin/', admin.site.urls),

    # Auth
    path('api/auth/login/', LoginView.as_view(), name='login'),
    path('api/auth/logout/', LogoutView.as_view(), name='logout'),
    path('api/auth/refresh/', TokenRefreshView.as_view(), name='token-refresh'),
    path('api/auth/me/', StaffProfileView.as_view(), name='staff-profile'),

    # Core modules
    path('api/patients/', include('patients.urls')),
    path('api/services/', include('services.urls')),
    path('api/billing/', include('billing.urls')),
    path('api/queues/', include('queues.urls')),
    path('api/notifications/', include('notifications.urls')),
    path('api/dashboard/', include('dashboard.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
