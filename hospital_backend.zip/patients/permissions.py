from rest_framework.permissions import BasePermission


class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.is_admin


class IsReceptionist(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and (
            request.user.is_receptionist or request.user.is_admin
        )


class IsFinance(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and (
            request.user.is_finance or request.user.is_admin
        )


class IsDoctor(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and (
            request.user.is_doctor or request.user.is_admin
        )


class IsReceptionistOrAdmin(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and (
            request.user.is_receptionist or request.user.is_admin
        )
