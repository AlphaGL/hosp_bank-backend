from django.db import transaction
from django.db.models import Max
from .models import DepartmentQueue
from django.utils import timezone


def next_queue_number(department, date):
    """Thread-safe next queue number for a department on a given date."""
    result = DepartmentQueue.objects.filter(
        department=department, date=date
    ).aggregate(max_num=Max('queue_number'))
    return (result['max_num'] or 0) + 1


@transaction.atomic
def add_visit_to_queues(visit):
    """
    After payment confirmation, create a DepartmentQueue entry for every
    unique department referenced by the visit's services.
    Emergency visits are inserted at position 1 and existing entries bumped.
    """
    today = timezone.localdate()
    departments = (
        visit.visit_services
        .values_list('service__department', flat=True)
        .distinct()
    )

    for dept in departments:
        if DepartmentQueue.objects.filter(visit=visit, department=dept).exists():
            continue  # Already queued — skip

        if visit.priority == 'emergency':
            # Bump all waiting entries in this dept today
            DepartmentQueue.objects.filter(
                department=dept, date=today, status=DepartmentQueue.STATUS_WAITING
            ).update(queue_number=models_F('queue_number') + 1)
            q_num = 1
        else:
            q_num = next_queue_number(dept, today)

        DepartmentQueue.objects.create(
            visit=visit,
            department=dept,
            queue_number=q_num,
            date=today,
        )

    # Update visit status
    from patients.models import Visit
    visit.status = Visit.STATUS_IN_QUEUE
    visit.save(update_fields=['status'])

    # Notify
    from notifications.utils import create_notification
    depts_str = ', '.join(departments)
    create_notification(
        event_type='patient_queued',
        visit=visit,
        message=f"{visit.patient.full_name} added to queue: {depts_str}",
    )


# Bring in F expression after defining utils
from django.db.models import F as models_F
